const grid = document.getElementById('productGrid');
const search = document.getElementById('search');
const category = document.getElementById('category');

async function loadProducts(){
  const params = new URLSearchParams();
  if(search.value.trim()) params.set('search', search.value.trim());
  if(category.value) params.set('category', category.value);
  const res = await fetch('/api/products?' + params);
  const products = await res.json();
  grid.innerHTML = products.map(p => `
    <article class="card">
      <img src="${p.imageUrl}" alt="${p.name}">
      <div class="card-body">
        <span class="tag">${p.category} • ${p.brand}</span>
        <h3>${p.name}</h3>
        <p>${p.description}</p>
        <div><span class="price">₹${p.pricePerDay}/day</span>
        <span class="${p.available?'available':'available unavailable'}">${p.available?'Available':'Rented'}</span></div>
        <button class="btn" ${p.available?'':'disabled'} onclick='openModal(${JSON.stringify(p)})'>
          ${p.available?'Rent now':'Unavailable'}
        </button>
      </div>
    </article>`).join('');
}

function openModal(p){
  document.getElementById('modal').classList.remove('hidden');
  document.getElementById('modalTitle').textContent = 'Rent ' + p.name;
  document.getElementById('modalPrice').textContent =
    `₹${p.pricePerDay}/day + ₹${p.securityDeposit} security deposit`;
  document.getElementById('productId').value = p.id;
  document.getElementById('message').textContent = '';
}
function closeModal(){ document.getElementById('modal').classList.add('hidden'); }

document.getElementById('rentalForm').addEventListener('submit', async e=>{
  e.preventDefault();
  const body = {
    productId:Number(document.getElementById('productId').value),
    customerName:document.getElementById('customerName').value,
    customerEmail:document.getElementById('customerEmail').value,
    startDate:document.getElementById('startDate').value,
    endDate:document.getElementById('endDate').value
  };
  const res = await fetch('/api/rentals',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
  const data = await res.json();
  const msg = document.getElementById('message');
  if(res.ok){
    msg.textContent = `Rental confirmed! Total: ₹${data.totalAmount}.`;
    msg.style.color = 'green';
    loadProducts(); loadRentals();
    setTimeout(closeModal,1800);
  }else{
    msg.textContent = data.message || 'Could not create rental.';
    msg.style.color = 'crimson';
  }
});

async function loadRentals(){
  const res=await fetch('/api/rentals');
  const rentals=await res.json();
  document.getElementById('rentalsList').innerHTML = rentals.length
    ? rentals.map(r=>`<div class="rental"><b>${r.product.name}</b> — ${r.customerName}<br>
      ${r.startDate} to ${r.endDate} • <b>₹${r.totalAmount}</b> • ${r.status}</div>`).join('')
    : '<p>No rental requests yet.</p>';
}

search.addEventListener('input', loadProducts);
category.addEventListener('change', loadProducts);
loadProducts(); loadRentals();
